package ua.alertalarm

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.concurrent.thread

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        val p = prefs(this)
        setContent {
            MaterialTheme {
                Surface {
                    var on by remember { mutableStateOf(p.getBoolean("on", false)) }
                    var obl by remember { mutableStateOf(p.getString("obl", OBLASTS[0])!!) }
                    var tok by remember { mutableStateOf(p.getString("tok", "")!!) }
                    var status by remember { mutableStateOf("") }
                    var menu by remember { mutableStateOf(false) }
                    val tp = rememberTimePickerState(p.getInt("h", 7), p.getInt("m", 0), true)
                    fun save() {
                        p.edit().putBoolean("on", on).putInt("h", tp.hour).putInt("m", tp.minute)
                            .putString("obl", obl).putString("tok", tok).apply()
                        schedule(this@MainActivity)
                    }
                    LaunchedEffect(tp.hour, tp.minute) { save() }
                    Column(
                        Modifier.statusBarsPadding().navigationBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Будильник з тривогою", style = MaterialTheme.typography.headlineMedium)
                        TimePicker(tp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Увімкнено  ")
                            Switch(checked = on, onCheckedChange = { on = it; save() })
                        }
                        Box {
                            OutlinedButton(onClick = { menu = true }) { Text("Область: $obl") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                OBLASTS.forEach { o ->
                                    DropdownMenuItem(text = { Text(o) }, onClick = { obl = o; menu = false; save() })
                                }
                            }
                        }
                        OutlinedTextField(value = tok, onValueChange = { tok = it; save() },
                            label = { Text("Токен alerts.in.ua") }, singleLine = true)
                        Button(onClick = {
                            status = "Перевіряю…"
                            thread {
                                status = when (airRaid(this@MainActivity)) {
                                    true -> "🔴 Тривога в області"
                                    false -> "🟢 Тривоги немає"
                                    null -> "Не вдалося перевірити (токен/інтернет)"
                                }
                            }
                        }) { Text("Перевірити тривогу зараз") }
                        Text(status)
                    }
                }
            }
        }
    }
}
