package ua.alertalarm

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

// Назви мають збігатися з полем location_oblast в API alerts.in.ua
val OBLASTS = listOf(
    "Автономна Республіка Крим", "Волинська область", "Вінницька область", "Дніпропетровська область",
    "Донецька область", "Житомирська область", "Закарпатська область", "Запорізька область",
    "Івано-Франківська область", "м. Київ", "Київська область", "Кіровоградська область",
    "Луганська область", "Львівська область", "Миколаївська область", "Одеська область",
    "Полтавська область", "Рівненська область", "м. Севастополь", "Сумська область",
    "Тернопільська область", "Харківська область", "Херсонська область", "Хмельницька область",
    "Черкаська область", "Чернівецька область", "Чернігівська область"
)

fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("p", Context.MODE_PRIVATE)

/** Ставить найближчий дзвінок (щодня в обраний час). */
fun schedule(c: Context) {
    val p = prefs(c)
    val am = c.getSystemService(AlarmManager::class.java)
    val pi = PendingIntent.getBroadcast(c, 1, Intent(c, AlarmReceiver::class.java).setAction("FIRE"),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    am.cancel(pi)
    if (!p.getBoolean("on", false)) return
    val t = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, p.getInt("h", 7)); set(Calendar.MINUTE, p.getInt("m", 0))
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    val show = PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    am.setAlarmClock(AlarmManager.AlarmClockInfo(t.timeInMillis, show), pi)
}

/** true = є повітряна тривога в обраній області, false = немає, null = не вдалося перевірити. */
fun airRaid(c: Context): Boolean? = try {
    val p = prefs(c)
    val con = URL("https://api.alerts.in.ua/v1/alerts/active.json").openConnection() as HttpURLConnection
    con.setRequestProperty("Authorization", "Bearer " + p.getString("tok", ""))
    con.connectTimeout = 10000; con.readTimeout = 10000
    val arr = JSONObject(con.inputStream.bufferedReader().readText()).getJSONArray("alerts")
    val region = p.getString("obl", OBLASTS[0])
    (0 until arr.length()).map { arr.getJSONObject(it) }
        .any { it.optString("location_oblast") == region && it.optString("alert_type") == "air_raid" }
} catch (e: Exception) { null }

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        schedule(c) // наступний дзвінок на завтра (або відновлення після перезавантаження)
        if (i.action == "FIRE") ContextCompat.startForegroundService(c, Intent(c, AlarmService::class.java))
    }
}

class AlarmService : Service() {
    @Volatile private var active = false
    private var player: MediaPlayer? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopAll(); return START_NOT_STICKY }
        if (active) return START_NOT_STICKY
        active = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("a", "Будильник", NotificationManager.IMPORTANCE_HIGH))
        val stopPi = PendingIntent.getService(this, 3, Intent(this, AlarmService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        fun note(text: String) = NotificationCompat.Builder(this, "a")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Будильник")
            .setContentText(text).setOngoing(true).setCategory(NotificationCompat.CATEGORY_ALARM)
            .addAction(0, "Вимкнути", stopPi).build()
        val types = if (Build.VERSION.SDK_INT >= 29)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, 1, note("Перевіряю тривогу…"), types)

        Thread {
            var fails = 0
            while (active) {
                val r = airRaid(this)
                fails = if (r == null) fails + 1 else 0
                if (r == false || fails >= 3) break // немає тривоги (або 3 збої підряд) -> дзвонимо
                nm.notify(1, note("Тривога в області — чекаю на відбій…"))
                Thread.sleep(20_000)
            }
            if (active) { nm.notify(1, note("Час вставати!")); ring() }
        }.start()
        return START_NOT_STICKY
    }

    private fun ring() {
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            setDataSource(this@AlarmService, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            isLooping = true; prepare(); start()
        }
        getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
    }

    private fun stopAll() {
        active = false
        player?.release(); player = null
        getSystemService(Vibrator::class.java).cancel()
        stopSelf()
    }

    override fun onDestroy() { active = false; player?.release(); super.onDestroy() }
}
